1. How to run your code

the first content you typed in the command line, either ’source1‘, ’source2‘ or ’source3‘
the second content you typed in the command line, either ’remote‘, or ’local‘

Example:
python WANG_YIFENG_hw7.py source1 remote

For source1:
we are grabbing the information for all the actors in 'the Ice and Fire', including the name, his gender, the time he was born, his aliases, his playedBy and his titles and TV series. 

For source2:
we are grabbing the name and the Per-Episode Estimate salaries for some actors played in 'Game of Thrones/HBO'

For source3:
we are grabbing the Movie Synopsis information for some popular movies. 

2. Any major “gotchas” to this code

You need to run 'python WANG_YIFENG_hw7.py source1 remote' at the first time for downloading the file.
This procedure will takes around 2 minutes. You have to wait.

3. Anything relevant to this project

If you are a big fun of 'the Ice and Fire' and you get some questions, 
like where Jon Snow was born?
How many actors and actresses are in this book?
How many aliases does Jon Snow get?
This is what you are looking for.

